<?php
define('BASE_DIR',dirname(__FILE__).'/');
define('REWRITE', true);
require(BASE_DIR.'protected/extensions/function_ext.php');
require(BASE_DIR.'protected/framework/core.php');