<?php
class DefaultController extends BaseController {

    function actionIndex(){
        
    }

}