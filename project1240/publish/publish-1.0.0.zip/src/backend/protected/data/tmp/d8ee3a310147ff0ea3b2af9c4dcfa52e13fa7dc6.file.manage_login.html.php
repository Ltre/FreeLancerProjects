<?php /* Smarty version Smarty-3.1.13, created on 2017-05-31 19:30:25
         compiled from "D:\InstalledApp\wamp\www\project1240\backend\protected\views\manage_login.html" */ ?>
<?php /*%%SmartyHeaderCode:6080592e869fbb6d14-26879351%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'd8ee3a310147ff0ea3b2af9c4dcfa52e13fa7dc6' => 
    array (
      0 => 'D:\\InstalledApp\\wamp\\www\\project1240\\backend\\protected\\views\\manage_login.html',
      1 => 1496230160,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '6080592e869fbb6d14-26879351',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_592e869fbdde24_03932188',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_592e869fbdde24_03932188')) {function content_592e869fbdde24_03932188($_smarty_tpl) {?><html>

    <head>

        <title>登录</title>
        <script src="https://cdn.bootcss.com/jquery/1.9.1/jquery.min.js"></script>
        <link href="//cdn.bootcss.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
        <script src="//cdn.bootcss.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    </head>

    <body>

        <div class="container" style="margin-top: 35px;">
            <div class="row">
                <div class="col-xs-6 col-xs-offset-3">
                    <div class="well bs-component">
                        <form class="form-horizontal" method="post" action="?r=manage/login">
                            <fieldset>
                                <legend align="right">登录</legend>
                                <div class="form-group">
                                    <label for="passport" class="col-lg-2 control-label">通行证</label>
                                    <div class="col-lg-10">
                                        <input type="text" class="form-control" id="passport" name="passport" placeholder="">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="password" class="col-lg-2 control-label">登入口令</label>
                                    <div class="col-lg-10">
                                        <input type="password" class="form-control" id="password" name="password" placeholder="">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-lg-10 col-lg-offset-2">
                                        <button id="form-login" type="submit" class="btn btn-primary">登 录</button>
                                    </div>
                                </div>
                            </fieldset>
                        </form>
                    </div>
                </div>
            </div>
        </div>

    </body>

</html><?php }} ?>