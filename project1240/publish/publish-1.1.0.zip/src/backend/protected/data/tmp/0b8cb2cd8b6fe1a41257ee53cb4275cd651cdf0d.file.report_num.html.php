<?php /* Smarty version Smarty-3.1.13, created on 2017-06-06 15:46:43
         compiled from "D:\InstalledApp\wamp\www\FreeLancerProjects\project1240\backend\protected\views\common\report_num.html" */ ?>
<?php /*%%SmartyHeaderCode:2694459365de381ecd5-22900684%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '0b8cb2cd8b6fe1a41257ee53cb4275cd651cdf0d' => 
    array (
      0 => 'D:\\InstalledApp\\wamp\\www\\FreeLancerProjects\\project1240\\backend\\protected\\views\\common\\report_num.html',
      1 => 1496625680,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2694459365de381ecd5-22900684',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_59365de3822b53_47859441',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_59365de3822b53_47859441')) {function content_59365de3822b53_47859441($_smarty_tpl) {?><script>
$(function(){
	$.get('<?php echo __template_url(array('r'=>"manage/reportNum"),$_smarty_tpl);?>
', function(j){
		if (j.rs) {
			$('#diy-tourist-num').text(j.data.touristNum);
			$('#diy-rootist-num').text(j.data.rootistNum);
			$('#diy-cookie-num').text(j.data.cookieNum);
		}
	}, 'jsonp');
});
</script><?php }} ?>