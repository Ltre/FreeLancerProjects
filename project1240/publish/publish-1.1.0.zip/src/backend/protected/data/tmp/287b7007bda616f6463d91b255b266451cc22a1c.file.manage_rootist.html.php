<?php /* Smarty version Smarty-3.1.13, created on 2017-06-03 18:22:29
         compiled from "D:\InstalledApp\wamp\www\project1240\backend\protected\views\manage_rootist.html" */ ?>
<?php /*%%SmartyHeaderCode:11391593289ade65e46-11585827%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '287b7007bda616f6463d91b255b266451cc22a1c' => 
    array (
      0 => 'D:\\InstalledApp\\wamp\\www\\project1240\\backend\\protected\\views\\manage_rootist.html',
      1 => 1496485347,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '11391593289ade65e46-11585827',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_593289ade90dc6_76565195',
  'variables' => 
  array (
    'keyword' => 0,
    'start' => 0,
    'end' => 0,
    'list' => 0,
    'v' => 0,
    'pages' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_593289ade90dc6_76565195')) {function content_593289ade90dc6_76565195($_smarty_tpl) {?><div class="row-fluid col-xs-12 well well-sm">
    <form class="navbar-form navbar-left" role="search">
        <div class="form-group">
            <input type="hidden" name="r" value="manage/rootist">
            <input name="keyword" type="text" class="form-control" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['keyword']->value, ENT_QUOTES, 'UTF-8', true);?>
" placeholder="关键字">
            <input name="start" size="16" type="text" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['start']->value, ENT_QUOTES, 'UTF-8', true);?>
" class="form-control form_datetime">
            <label class="">至</label>
            <input name="end" size="16" type="text" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['end']->value, ENT_QUOTES, 'UTF-8', true);?>
" class="form-control form_datetime">
        </div>
        <button type="submit" class="btn btn-default">搜索</button>
    </form>
</div>

<div class="row-fluid">
    <?php if (empty($_smarty_tpl->tpl_vars['list']->value)){?>
        <p align="center">没有记录</p>
    <?php }else{ ?>
        <table class="table table-bordered table-striped">
            <colgroup>
                <col class="col-xs-1">
                <col class="col-xs-7">
            </colgroup>
            <thead>
                <tr>
                    <th id="sb1">流水号</th>
                    <th>IP</th>
                    <th>访问时间</th>
                    <th>URL</th>
                    <th>管理员ID</th>
                    <th>管理员账号</th>
                </tr>
            </thead>
            <tbody>
                <?php  $_smarty_tpl->tpl_vars['v'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['v']->_loop = false;
 $_smarty_tpl->tpl_vars['k'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['list']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['v']->key => $_smarty_tpl->tpl_vars['v']->value){
$_smarty_tpl->tpl_vars['v']->_loop = true;
 $_smarty_tpl->tpl_vars['k']->value = $_smarty_tpl->tpl_vars['v']->key;
?>
                <tr>
                    <th scope="row">
                        <code><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['v']->value['id'], ENT_QUOTES, 'UTF-8', true);?>
</code>
                    </th>
                    <td><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['v']->value['ip'], ENT_QUOTES, 'UTF-8', true);?>
</td>
                    <td><?php echo htmlspecialchars(date('Y-m-d H:i:s',$_smarty_tpl->tpl_vars['v']->value['vtime']), ENT_QUOTES, 'UTF-8', true);?>
</td>
                    <td style="overflow-x: auto;"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['v']->value['url'], ENT_QUOTES, 'UTF-8', true);?>
</td>
                    <td><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['v']->value['admin_id'], ENT_QUOTES, 'UTF-8', true);?>
</td>
                    <td><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['v']->value['passport'], ENT_QUOTES, 'UTF-8', true);?>
</td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
    <?php }?>
</div>

<div class="row-fluid">
    <?php echo smarty_function_bs3page(array('page'=>$_smarty_tpl->tpl_vars['pages']->value,'r'=>"manage/rootist",'keyword'=>$_smarty_tpl->tpl_vars['keyword']->value,'start'=>$_smarty_tpl->tpl_vars['start']->value,'end'=>$_smarty_tpl->tpl_vars['end']->value),$_smarty_tpl);?>

</div>

<script>
    $(".form_datetime").datetimepicker({
        format: 'yyyy-mm-dd hh:ii:ss',
        autoclose: true,
        todayBtn: true
    });
</script><?php }} ?>