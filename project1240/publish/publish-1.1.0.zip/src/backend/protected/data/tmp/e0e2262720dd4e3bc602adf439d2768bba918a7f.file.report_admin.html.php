<?php /* Smarty version Smarty-3.1.13, created on 2017-06-05 09:17:23
         compiled from "D:\InstalledApp\wamp\www\project1240\backend\protected\views\common\report_admin.html" */ ?>
<?php /*%%SmartyHeaderCode:2500259328b5601ea39-56268625%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'e0e2262720dd4e3bc602adf439d2768bba918a7f' => 
    array (
      0 => 'D:\\InstalledApp\\wamp\\www\\project1240\\backend\\protected\\views\\common\\report_admin.html',
      1 => 1496487516,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2500259328b5601ea39-56268625',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_59328b560228b8_02685211',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_59328b560228b8_02685211')) {function content_59328b560228b8_02685211($_smarty_tpl) {?><script>
var baseDomain = (location.href.match(/^https?\:\/\/([-\w]+(\.[-\w]+)+)\/?/) || [,'']) [1];
var reportUrl = '';
switch (baseDomain) {
    case 'log.fengzhang.com':
        reportUrl = 'http://log.fengzhang.com/reportAdmin';
        break;
    case 'project1-log.yooo.moe':
        reportUrl = 'http://project1-log.yooo.moe/reportAdmin';
        break;
    case '127.0.0.1':
        //reportUrl = 'http://project1-log.yooo.dev/report';
        reportUrl = 'http://127.0.0.1/project1240/backend/?r=manage/reportAdmin';
        break;
}
if (reportUrl) (new Image).src = reportUrl;
</script><?php }} ?>