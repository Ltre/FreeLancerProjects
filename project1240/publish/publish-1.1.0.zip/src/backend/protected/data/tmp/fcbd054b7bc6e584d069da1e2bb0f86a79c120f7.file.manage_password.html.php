<?php /* Smarty version Smarty-3.1.13, created on 2017-06-03 18:41:45
         compiled from "D:\InstalledApp\wamp\www\project1240\backend\protected\views\manage_password.html" */ ?>
<?php /*%%SmartyHeaderCode:2572159328eae6b6141-08097434%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'fcbd054b7bc6e584d069da1e2bb0f86a79c120f7' => 
    array (
      0 => 'D:\\InstalledApp\\wamp\\www\\project1240\\backend\\protected\\views\\manage_password.html',
      1 => 1496486501,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2572159328eae6b6141-08097434',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_59328eae6d16c1_70538808',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_59328eae6d16c1_70538808')) {function content_59328eae6d16c1_70538808($_smarty_tpl) {?><div class="row-fluid">
    <div class="col-xs-offset-1 col-xs-5">
        <div class="bs-component">
            <form class="form-horizontal" method="post" action="?r=manage/password">
                <fieldset>
                    <!-- <legend align="right">登录</legend> -->
                    <div class="form-group">
                        <label for="passport" class="col-lg-2 control-label">旧密码</label>
                        <div class="col-lg-10">
                            <input type="password" class="form-control" id="raw" name="raw" placeholder="">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="password" class="col-lg-2 control-label">新密码</label>
                        <div class="col-lg-10">
                            <input type="password" class="form-control" id="new" name="new" placeholder="">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="password" class="col-lg-2 control-label">再次输入</label>
                        <div class="col-lg-10">
                            <input type="password" class="form-control" id="second" name="second" placeholder="">
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-lg-10 col-lg-offset-2">
                            <button type="submit" class="btn btn-primary">修改密码</button>
                        </div>
                    </div>
                </fieldset>
            </form>
        </div>
    </div>
</div>


<script>
$(function(){
    $('form').submit(function(){
        var raw = $('#raw').val();
        var newp = $('#new').val();
        var sec = $('#second').val();
        if (! raw || ! newp || ! sec) {
            alert('请填写完整');
            return false;
        }
        if (newp != sec) {
            alert('两次输入的新密码不一致');
            return false;
        }
    });
});
</script><?php }} ?>