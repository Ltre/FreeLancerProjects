<?php /* Smarty version Smarty-3.1.13, created on 2017-06-06 15:46:43
         compiled from "D:\InstalledApp\wamp\www\FreeLancerProjects\project1240\backend\protected\views\common\report_admin.html" */ ?>
<?php /*%%SmartyHeaderCode:2784359365de3816fd9-17689423%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'e105cf5af7aeaf52da83a8dd90e0d2f54750eed7' => 
    array (
      0 => 'D:\\InstalledApp\\wamp\\www\\FreeLancerProjects\\project1240\\backend\\protected\\views\\common\\report_admin.html',
      1 => 1496735166,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2784359365de3816fd9-17689423',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_59365de3816fd9_32272244',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_59365de3816fd9_32272244')) {function content_59365de3816fd9_32272244($_smarty_tpl) {?><script>
var baseDomain = (location.href.match(/^https?\:\/\/([-\w]+(\.[-\w]+)+)\/?/) || [,'']) [1];
var reportUrl = '';
switch (baseDomain) {
    case 'log.fengzhang.com':
        reportUrl = 'http://log.fengzhang.com/reportAdmin';
        break;
    case 'project1-log.yooo.moe':
        reportUrl = 'http://project1-log.yooo.moe/reportAdmin';
        break;
    case '127.0.0.1':
        reportUrl = 'http://127.0.0.1/FreeLancerProjects/project1240/backend/?r=manage/reportAdmin';
        break;
}
if (reportUrl) (new Image).src = reportUrl;
</script><?php }} ?>