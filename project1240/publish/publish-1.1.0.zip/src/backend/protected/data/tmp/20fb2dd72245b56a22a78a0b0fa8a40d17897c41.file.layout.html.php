<?php /* Smarty version Smarty-3.1.13, created on 2017-06-06 15:46:43
         compiled from "D:\InstalledApp\wamp\www\FreeLancerProjects\project1240\backend\protected\views\layout.html" */ ?>
<?php /*%%SmartyHeaderCode:1881359365de36a7c86-88432470%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '20fb2dd72245b56a22a78a0b0fa8a40d17897c41' => 
    array (
      0 => 'D:\\InstalledApp\\wamp\\www\\FreeLancerProjects\\project1240\\backend\\protected\\views\\layout.html',
      1 => 1496625680,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1881359365de36a7c86-88432470',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'baseWebPath' => 0,
    'route' => 0,
    '__template_file' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_59365de37b5542_77394588',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_59365de37b5542_77394588')) {function content_59365de37b5542_77394588($_smarty_tpl) {?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>后台</title>
<script src="//cdn.bootcss.com/jquery/1.9.1/jquery.min.js"></script>
<link rel="stylesheet" href="//cdn.bootcss.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
<script src="//cdn.bootcss.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>

<script type="text/javascript" src="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['baseWebPath']->value, ENT_QUOTES, 'UTF-8', true);?>
/res/bootstrap-datepicker/bootstrap-datetimepicker.min.js" charset="UTF-8"></script>
<script type="text/javascript" src="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['baseWebPath']->value, ENT_QUOTES, 'UTF-8', true);?>
/res/bootstrap-datepicker/bootstrap-datetimepicker.zh-CN.js" charset="UTF-8"></script>
<link href="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['baseWebPath']->value, ENT_QUOTES, 'UTF-8', true);?>
/res/bootstrap-datepicker/bootstrap-datetimepicker.min.css" rel="stylesheet" media="screen">

</head>
<body>
<!-- <div class="navbar navbar-inverse navbar-fixed-top">
    <div class="navbar-inner">
        <div class="container">
           
        </div>
    </div>
</div> -->
    <div class="container-fluid">
        <br>
        <div class="row-fluid well">
            <h1 align="center">风杖网络后台</h1>
        </div>
        <div class="row-fluid">
            <ul class="col-xs-2 nav nav-pills nav-stacked">
                  <li role="presentation" class="<?php if ($_smarty_tpl->tpl_vars['route']->value=='manage/index'){?>active<?php }?>"><a href="<?php echo __template_url(array('r'=>'manage/index'),$_smarty_tpl);?>
">访问日志</a></li>
                  <li role="presentation" class="<?php if ($_smarty_tpl->tpl_vars['route']->value=='manage/rootist'){?>active<?php }?>"><a href="<?php echo __template_url(array('r'=>'manage/rootist'),$_smarty_tpl);?>
">审计日志</a></li>
                  <li role="presentation" class="<?php if ($_smarty_tpl->tpl_vars['route']->value=='manage/password'){?>active<?php }?>"><a href="<?php echo __template_url(array('r'=>'manage/password'),$_smarty_tpl);?>
">修改密码</a></li>
                  <li role="presentation"><a href="<?php echo __template_url(array('r'=>'manage/logout'),$_smarty_tpl);?>
">退出</a></li>
                  <li class="well" role="presentation">
                      <p>历史游客总数：<span id="diy-cookie-num">0</span></p>
                      <p>历史访问总数：<span id="diy-tourist-num">0</span></p>
                      <p>历史审计总数：<span id="diy-rootist-num">0</span></p>
                  </li>
            </ul>
            <div class="col-xs-10">
                <?php ob_start();?><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['__template_file']->value, ENT_QUOTES, 'UTF-8', true);?>
<?php $_tmp1=ob_get_clean();?><?php echo $_smarty_tpl->getSubTemplate ($_tmp1, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

            </div>
        </div>
    </div>

    <?php echo $_smarty_tpl->getSubTemplate ("common/report_admin.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>


    <?php echo $_smarty_tpl->getSubTemplate ("common/report_num.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>


</body>
</html><?php }} ?>