<?php
class TestController extends BaseController {
    
    public function init(){

    }

    public function actionHehe(){
        var_dump($_SESSION);
    }

}